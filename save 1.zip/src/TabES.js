const TabES = () => {
    return ( 
    <div className="child-tab" data-aos="fade-right"  data-aos-duration="1000" data-aos-once="true"> 
        <h3>Ecole Nationale Supérieure d'Informatique et d'Analyse des Systèmes, Rabat </h3> 
        <h4> September 2019 - September 2022</h4>
        <p> Option : Software Engineering (GL) <br/>  </p>
        <ul>
            <li>Successfully obtained my Software Engineering Degree with honors</li>
        </ul>
        <p> These were the three years where I dived head first into Computer Science, I'm still as fascinated as I was when I was a kid with how everything works.<br/> Other than my soft skills that I was able to hone, I had the chance to discover many different technologies and work on various projects. I've learned alot during this period and I'm looking forward to finally being able to leverage my skills in a professional context</p>
    </div> );
}
 
export default TabES;