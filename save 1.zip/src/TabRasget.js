const TabRasget = () => {
    return ( 
        <div className="child-tab" data-aos="fade-left"  data-aos-duration="1000" data-aos-once="true" > 
            <h3>Software Engineering Intern at <span className="colored">Rasget, Valenciennes, France (remote)</span></h3> 
            <h4> March 2022 - September 2022</h4>
            <p className="current-position"> This is my current position, it's a blockchain and fullstack internship. <br/>
            I'll tell you all about it once it's concluded!</p>
        </div> 
     );
}
 
export default TabRasget;