
import './App.scss';
import Resume from "./Marouane Asselman Resume (1).pdf";
import Navbar from './Navbar';
import Card from './Card';
import Title from './Title';
import Picture from './picture.png';
import AOS from 'aos';
import Tabs from './Tabs';
import Slider from './Slider';
function App() {
  
  return (
    <div className="App">
    <Navbar></Navbar>
    <div className="main">
      <div className="intro-section" id="intro-section">
        <h3> Hey there, I am </h3>
        <h1> Marouane ASSELMAN.</h1>
        <h2> And I build all sorts of software.</h2>
        <p> 
        I am a software engineer building great digital experiences.
        A jack of many trades, and a master of some, my areas of expertise include but are not limited to : 
        <ul>
          <li>Fullstack  Responsive Web Development</li>
          <li>Blockchain Development</li>
          <li>Data Science and Data Scraping</li>
          <li> UI/UX Design</li>
          <li>Automation</li>
        </ul>
        <p>For a brief overview, you can <span className="colored-text">download my resume</span> here !</p>
        <a href={Resume} download="Marouane Asselman Resume" target='_blank' rel="noreferrer" >
        <button id="resume-download"  download>Download my Resume</button>
        </a>
        
        
        </p>
        
      </div>
      <Title number="01." name="About me" ></Title>
      <p id="About">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sollicitudin urna felis, eu ultricies urna ullamcorper vitae. Integer laoreet, dolor egestas fringilla vulputate, nunc magna elementum diam, ut laoreet sapien ante sit amet dolor. Praesent in gravida leo, et consectetur elit. Nunc tellus lectus, posuere nec egestas eget, finibus fringilla enim. Vestibulum sit amet sollicitudin urna. Donec tempor varius massa, nec dictum risus condimentum ac. Aliquam erat volutpat. Duis urna magna, volutpat ut rutrum vel, placerat eget orci. Morbi mauris orci, vestibulum ac hendrerit eget, blandit at nisi. In hac habitasse platea dictumst. Nam augue sem, tincidunt nec velit quis, rhoncus egestas turpis. Sed consequat sodales iaculis. Aenean ut ante posuere, placerat tortor non, euismod tellus.

      Praesent <span className='colored-text'> id dui luctus, bibendum lacus eget, fringilla turpis. </span> Nullam facilisis massa at hendrerit convallis. Suspendisse lacinia dignissim tempus. Nulla rhoncus consectetur ligula eu tempus. Aliquam commodo sollicitudin erat sit amet tincidunt. Quisque ac molestie sem. Aliquam ornare quam tortor. Aliquam non dignissim turpis. Nullam placerat dui sed erat vulputate mattis.

      Donec quis convallis magna. Sed et mauris porta quam ornare rhoncus. Integer mi risus, maximus eget egestas vel, dapibus quis ipsum. Aenean pulvinar suscipit sem, vel porttitor leo sollicitudin at. Donec sollicitudin venenatis nibh, sit amet tristique neque interdum sed. Aliquam vel consequat sapien. Vivamus tempor suscipit sapien non dignissim. Morbi vel enim imperdiet, mattis ante id, tincidunt tellus.</p>
      
      <div className="picture" >
        <div className="filter-box"></div>
        <img src={Picture} alt="The Spaceman" className='img-picture'/>
      </div>
      <Title number="02." name="Education"></Title>
      <Tabs nbtabs={3} tabslist={["High School","Preparatory Classes", "Engineering School"]} id="Dashboard"></Tabs>

      

      <Title number="03." name="Experience"></Title>
      <Tabs nbtabs={4} tabslist={["IntellCap","DLS Inc.", "Rasget","Freelance"]} id="Experience"></Tabs>

      <Title number="04." name="Projects"></Title>
      <div className="card-div" >
        <Card tools={["python","react","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={3} ></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={4}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={5}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={2}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={2}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={6}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={5}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={12}></Card>
        <Card tools={["react","python","css3","docker"]} title="Developing an Algo trading Solution" description="A fully automatic tranding bot, that waits for certain market signals and leverages an API to make trades." team={4}></Card>
      </div>



      <Title number="05." name="Theme"></Title>
      <Slider></Slider>

      <Title number="06." name="Contact"></Title>
      <div className="footer">
      <h4>Fueled by caffeine and a dream <br/> Designed and Built by Marouan ASSELMAN - 2022 <br/> Spaceman Labs ©</h4>
    </div>

    </div>
    
    </div>
  );
}

export default App;
