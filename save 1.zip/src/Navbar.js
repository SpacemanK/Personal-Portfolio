import {useRef} from "react";
import {FaBars, FaTimes} from "react-icons/fa";
import { Link } from "react-scroll";
const Navbar = () => {

    const navRef = useRef();

    const showNavbar = () => {
        navRef.current.classList.toggle("responsive-nav");
    }
    return ( 
    <header>
        <div className="navbar">

            <Link  to="intro-section" offset={-100} spy={true} smooth={true}  duration={300}>
                <div className="logo">
                </div>
            </Link>
                
    
            
            <nav ref={navRef}>
            <button className="nav-btn nav-close-btn" onClick={showNavbar}>
                    <FaTimes></FaTimes>
                </button>
                <Link to="About" offset={-100} spy={true} smooth={true}  duration={300}> <a href="#About" onClick={showNavbar}>01. <br/> About</a></Link>
               
                <a href="#Education" onClick={showNavbar}>02. <br/> Education</a>
                <a href="#Experience" onClick={showNavbar}>03. <br/> Experience</a>
                <a href="#PersonalProjects" onClick={showNavbar} >04. <br/> Projects</a>
                <a href="#Contact" onClick={showNavbar}> 05. <br/> Theme</a>
                <a href="#Contact" onClick={showNavbar}> 06. <br/> Contact</a>
            </nav>
            <button className="nav-btn" onClick={showNavbar}>
                <FaBars></FaBars>
            </button>
        </div>
    </header>
     );
}
 
export default Navbar;