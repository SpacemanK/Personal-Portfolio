const Linebreak = () => {
    return ( 
        <div className="line-break">
          <div className="line-break-one">
          <hr></hr>
          </div>
          <div className="line-break-two">
            <hr></hr>
          </div>
          <div className="line-break-three">
            <hr></hr>
          </div>
          
        </div>
     );
}
 
export default Linebreak;