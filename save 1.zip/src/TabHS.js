const TabHS = () => {
    return ( 
        <div className="child-tab" data-aos="fade-right"  data-aos-duration="1000" data-aos-once="true"> 
               <h3>Moulay Youssef Technical High-School(LTMY), Tangier</h3> 
            <h4> September 2015 - July 2017</h4>
            <p> Option : Mathematical Sciences, Engineering Sciences (SM-B)  <br/>  </p>
            <ul>
                <li>Successfully passed the Baccalaureate exam and graduated with highest honor (Très Bien)</li>
                <li> Chose Preparatory Classes to compete for a seat in Engineering Schools</li>
            </ul>
            <p>I believe theses 3 years really helped shape my personality and aided me in  building a clearer vision for my future,
            It was during these three years that I chose to pursue a career in Engineering. 

            </p>
        </div>
        
     );
}
 
export default TabHS;