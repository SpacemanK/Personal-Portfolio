const Slider = () => {
    return ( 
        <div className="slider">
            <div className="slider-image"></div>
            <div className="slider-image"></div>
            <div className="slider-image"></div>
        </div>
     );
}
 
export default Slider;