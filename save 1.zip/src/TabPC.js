const TabPC = () => {
    return (
        <div className="child-tab" data-aos="fade-right"  data-aos-duration="1000" data-aos-once="true" > 
            <h3>Moulay Al Hassan Preparatory Classes (CPGE), Tangier</h3> 
            <h4> September 2017 - July 2019</h4>
            <p> Option : Physics and Engineering Sciences (PSI) <br/>  </p>
            <ul>
                <li>Successfully passed the CNC exam and ranked 34/880</li>
                <li> Chose Software Engineering at ENSIAS Rabat  as a first pick and got admitted </li>
            </ul>
            <p> These 2 years at CPGE helped me grow alot, CNC is known for being the most selective exam in Morocco and preparing for this exam wasn't an easy journey. 
           I've had the chance to grow alot intellectually and make better usage of curiosity and analytical prowess.
          <br/> I consider these two years to be the point in time where I left the bird's nest, and went to live on campus. I've met many wonderful people during this couple of years and had the chance to grow a lot as a person .
           
            </p>
        </div> 
         );
}
 
export default TabPC;